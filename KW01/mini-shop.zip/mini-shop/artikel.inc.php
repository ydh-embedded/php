<?php
$array_schoko = array(
  "s-1" => "Weiße Schokolade",
  "s-2" => "Vollmilch-Schokolade",
  "s-3" => "Bio-Vollmilch-Schokolade",
  "s-4" => "Zartbitter-Schokolade"
);
$array_praline = array(
  "p-1" => "Marzipan-Pralinen",
  "p-2" => "Mokka-Pralinen",
  "p-3" => "Nougat-Pralinen",
  "p-4" => "Walnuss-Pralinen"
);