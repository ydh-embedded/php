<?php session_start(); ?>
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Honigschop Bestellformular</title>
  <style>
    table, th, td {border: 1px solid gray;}
    th, td {padding: 5px;}
  </style>
</head>
<body>
  <h1>Übung Honigbestellung</h1>
  <p>Bitte geben Sie die Bestellmenge ein (Einheit: 500g Glas):</p>

  <form action="u_bestellung.php" method="post">
    <table>
      <tr>
        <th>Honig</th>
        <th>Menge</th>
      </tr>

      <tr>
        <td>Akazienhonig</td>
        <td><input type="number" name="ah"></td>
      </tr>
      <tr>
        <td>Heidehonig</td>
        <td><input type="number" name="hh"></td>
      </tr>
      <tr>
        <td>Kleehonig</td>
        <td><input type="number" name="kh"></td>
      </tr>
      <tr>
        <td>Tannenhonig</td>
        <td><input type="number" name="th"></td>
      </tr>
    
      <tr>
        <td colspan="2"><button type="submit">Absenden</button></td>
      </tr>
    </table>
  </form>
</body>
</html>