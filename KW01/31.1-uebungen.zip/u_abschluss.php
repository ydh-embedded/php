<?php session_start(); ?>
<!DOCTYPE html>
<html lang="de">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kasse</title>
</head>

<body>
  <h1>Honigbestellung - Abschluss</h1>
  <?php if (empty($_POST)) : ?>
    <form action="<?= $_SERVER['SCRIPT_NAME']; ?>" method="post">
      <p>Bitte geben Sie noch Ihre Kontaktdaten ein:</p>
      <p>Vorname: <input type="text" name="vorname"></p>
      <p>Nachname: <input type="text" name="nachname"></p>
      <p>Wohnort: <input type="text" name="ort"></p>
      <p>Mailadresse: <input type="email" name="email"></p>
      <p><button type="submit">Abschicken</button></p>
    </form>
  <?php else : ?>
    <p>Dies sind die in der Session gesammelten Daten:</p>
    <p>
      <?php if (!empty($_SESSION)) : ?>
    <p>
      <?php foreach ($_SESSION as $key => $value) : ?>
        <?php if ($key === 'ah') echo "<i>Akazienhonig</i>: $value<br>"; ?>
        <?php if ($key === 'hh') echo "<i>Heidehonig</i>: $value<br>"; ?>
        <?php if ($key === 'kh') echo "<i>Kleehonig</i>: $value<br>"; ?>
        <?php if ($key === 'th') echo "<i>Tannenhonig</i>: $value<br>"; ?>
      <?php endforeach; ?>
      Vorname: <?= $_POST['vorname']; ?><br>
      Nachname: <?= $_POST['nachname']; ?><br>
      Wohnort: <?= $_POST['ort']; ?><br>
      Mailadresse: <?= $_POST['email']; ?>
    </p>
    <?php else : ?>
      <p>Keine Bestelldaten gefunden.</p>
    <?php endif; ?>
  </p>
  <?php
    /**
     * Durch zerstören der Session wird nur das Server-Cookie geöscht!
     * Um die Session komplett zu löschen, sollte das Browser-Cookie ebenfalls gelöscht werden.
     * Ist in den PHP-Einstellungen session.use_strict_mode aktiviert ist dies nicht erforderlich. 
     * Häufig hat man aber selbst keinen Einfluss auf diese Einstellungen.
     * Weitere Informationen unter https://www.php.net/manual/de/function.session-destroy.php.
     * */
    if (ini_get("session.use_cookies")) {
      $params = session_get_cookie_params();
      setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
      );
    }
    // Session zerstören
    $_SESSION = array();
    session_destroy();
  ?>
  <p>Damit ist die Session beendet. <a href="u_formular.php">Klicken Sie hier</a> um eine neue Session zu beginnen.</p>
<?php endif; ?>
</body>

</html>