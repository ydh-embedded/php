<?php session_start(); ?>
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Honigshop Bestellübersicht</title>
</head>
<body>
  <h1>Bestellung</h1>

  <p>Sie haben folgende Mengen bestellt:</p>

  <?php
    
  if( ! empty($_POST) ) {
    $ah = $_POST['ah'];
    $hh = $_POST['hh'];
    $kh = $_POST['ah'];
    $th = $_POST['th'];
  ?>
    <p>
      <?php if( ! empty( trim($ah) ) ) echo "<i>Akazienhonig</i>: $ah Gläser<br>"; $_SESSION['ah'] = $ah; ?>
      <?php if( ! empty( trim($hh) ) ) echo "<i>Heidehonig</i>: $hh Gläser<br>"; $_SESSION['hh'] = $hh; ?>
      <?php if( ! empty( trim($kh) ) ) echo "<i>Kleehonig</i>: $kh Gläser<br>"; $_SESSION['kh'] = $kh; ?>
      <?php if( ! empty( trim($th) ) ) echo "<i>Tannenhonig</i>: $th Gläser<br>"; $_SESSION['th'] = $th; ?>
    </p>

    <p><i>Die Session-ID lautet: <?= session_id(); ?></i></p>

    <p><a href="u_abschluss.php">Weiter zur Eingabe persönlicher Daten</a> und dem Abschluss der Eingabe.</p>
  <?php } ?>
</body>
</html>