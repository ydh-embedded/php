@csrf
<div>
    <ul>
        @foreach ($errors->all() as $error)

        <li>  {{  $error }}    </li>        {{-- für die en Variante         --}}
        <li>  {!! $error !!}   </li>        {{-- für die de Variante "deutsche"   --}}
        @endforeach
    </ul>
</div>