<x-category-child heading="{{$heading}}" title="{{$title}}">{{$content}}</x-category-child>
<x-category-child footer="{{$footer}}"></x-category-child>